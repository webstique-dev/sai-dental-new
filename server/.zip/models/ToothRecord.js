const mongoose = require('mongoose');
const { capitalizeWords } = require('../utils/formatters.js');

const toothConditionOptions = [
  'Healthy',
  'Decayed',
  'Caries',
  'Missing',
  'Filling',
  'RCT',
  'Crown',
  'Bridge',
  'Implant',
  'Extraction',
  'Restored',
  'Prosthetic',
  'Mobility',
  'Other',
];

const toothHistorySchema = new mongoose.Schema(
  {
    condition: {
      type: String,
      required: true,
      set: capitalizeWords,
    },
    treatment: {
      type: String,
      trim: true,
      default: '',
      set: capitalizeWords,
    },
    date: {
      type: Date,
      default: Date.now,
    },
    doctor: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
    },
    notes: {
      type: String,
      trim: true,
      default: '',
      set: capitalizeWords,
    },
    consultation: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Consultation',
      default: null,
    },
    deleted: {
      type: Boolean,
      default: false,
    },
    deletedAt: {
      type: Date,
      default: null,
    },
    deletedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      default: null,
    },
  },
  { _id: true }
);

const toothRecordSchema = new mongoose.Schema(
  {
    patient: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Patient',
      required: true,
    },
    toothNumber: {
      type: Number,
      required: true,
    },
    currentCondition: {
      type: String,
      default: 'Healthy',
    },
    history: [toothHistorySchema],
  },
  {
    timestamps: true,
  }
);

// Compound unique index on (patient, toothNumber)
toothRecordSchema.index({ patient: 1, toothNumber: 1 }, { unique: true });

module.exports = mongoose.model('ToothRecord', toothRecordSchema);
module.exports.toothConditionOptions = toothConditionOptions;
