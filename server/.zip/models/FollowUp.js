const mongoose = require('mongoose');
const { capitalizeWords } = require('../utils/formatters.js');

const followUpStatusOptions = [
  'Pending',
  'Scheduled',
  'Checked-In',
  'In Consultation',
  'Completed',
  'Cancelled',
  'No Show',
  'Missed',
];

const followUpSchema = new mongoose.Schema(
  {
    patient: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Patient',
      required: true,
    },
    doctor: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      default: null,
    },
    consultation: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Consultation',
      default: null,
    },
    recommendedDate: {
      type: Date,
    },
    reason: {
      type: String,
      trim: true,
      default: '',
      set: capitalizeWords,
    },
    instructions: {
      type: String,
      trim: true,
      default: '',
      set: capitalizeWords,
    },
    notes: {
      type: String,
      trim: true,
      default: '',
      set: capitalizeWords,
    },
    treatmentStatus: {
      type: String,
      trim: true,
      default: '',
      set: capitalizeWords,
    },
    scheduledAppointment: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Appointment',
      default: null,
    },
    cancellationReason: {
      type: String,
      trim: true,
      default: '',
      set: capitalizeWords,
    },
    status: {
      type: String,
      enum: followUpStatusOptions,
      default: 'Scheduled',
    },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
    },
  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.model('FollowUp', followUpSchema);
module.exports.followUpStatusOptions = followUpStatusOptions;
