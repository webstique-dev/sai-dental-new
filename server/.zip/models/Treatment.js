const mongoose = require('mongoose');
const { capitalizeWords } = require('../utils/formatters.js');

const treatmentSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
      trim: true,
      set: capitalizeWords,
    },
    code: {
      type: String,
      trim: true,
      default: '',
    },
    category: {
      type: String,
      trim: true,
      default: 'General',
      set: capitalizeWords,
    },
    description: {
      type: String,
      trim: true,
      default: '',
      set: capitalizeWords,
    },
    defaultCost: {
      type: Number,
      default: 0,
      min: 0,
    },
    isActive: {
      type: Boolean,
      default: true,
    },
  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.model('Treatment', treatmentSchema);
